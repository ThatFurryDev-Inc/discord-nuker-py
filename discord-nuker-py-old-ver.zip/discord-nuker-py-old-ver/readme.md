# discord-nuker-py | V 1.0.1

## Overview
This piece of code will obliterate any server you want. EDUCATIONAL PURPOSES ONLY!

## Features
- Renaming server
- Deleting all existing channels
- Making new channels
- Spamming with your custom message

## Commands
### NO COMMANDS! JUST START THE CODE IN VSCODE AND IT WILL DESTROY!
# Instructions:
- If you don't want your server destroyed, add you server ID to excluded_servers[your_id_in_the_main_py_code] without the '' or ""
- Replace bot.run's 
- Add the bot to the server you want to destroy
- Start the code in VSCODE
- Destroy

## Extras
1. You can change the channelsname, and quantity, that should be generated after the deletion.
2. You can change the name to rename the server to
3. You can customize the message it should spam in the code-generated channels.